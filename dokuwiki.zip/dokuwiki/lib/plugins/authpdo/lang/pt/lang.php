<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Paulo Schopf <pschopf@gmail.com>
 * @author Maykon Oliveira <maykonoliveira850@gmail.com>
 * @author Paulo Carmino <contato@paulocarmino.com>
 */
$lang['connectfail']           = 'Erro ao conectar o banco de dados.';
$lang['userexists']            = 'Desculpe, esse login já está sendo usado.';
$lang['writefail']             = 'Não é possível modificar os dados do usuário. Por favor, informe o Wiki-Admin';

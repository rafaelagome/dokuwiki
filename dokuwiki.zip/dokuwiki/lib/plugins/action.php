<?php
\dokuwiki\Debug\DebugHelper::dbgDeprecatedFunction(
    'Do not require() files yourself. Autoloading', 0, basename(__FILE__)
);

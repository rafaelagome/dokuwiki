<?php

namespace dokuwiki\plugin\config\core\Setting;

/**
 * Class setting_hidden
 */
class SettingHidden extends Setting {
    // Used to explicitly ignore a setting in the configuration manager.
}
